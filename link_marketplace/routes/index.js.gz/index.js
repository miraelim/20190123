module.exports = {
    getHomePage: (req, res) => {
        let query = "SELECT * FROM dataPoint_link ORDER BY id ASC"; // query database to get all the players

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
	    console.log("Result is "+result);
            res.render('index.ejs', {
                title: "Welcome to dataPoint marketplace | Get dataPoints"
                ,players: result
            });
        });
    },
};
