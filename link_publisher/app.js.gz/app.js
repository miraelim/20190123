const express = require('express');
const fileUpload = require('express-fileupload');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const app = express();

const {getHomePage} = require('./routes/index');
const {addLink} = require('./routes/link');
const client_id ='link_resolver';
const redirect_uri='http://141.223.83.26:5000/authentication';
const client_secret='bGlua19yZXNvbHZlcg';
const client_auth='bGlua19yZXNvbHZlcjpiR2x1YTE5eVpYTnZiSFpsY2c='

// const {addPlayerPage, addPlayer, deletePlayer, editPlayer, editPlayerPage} = require('./routes/player');
const port = 5000;
var token='';

// create connection to database
// the mysql.createConnection function takes in a configuration object which contains host, user, password and the database name.
const db = mysql.createConnection ({
    host: 'localhost',
    user: 'root',
    password: '123',
    database: 'link_resolver'
});

// connect to database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;

// configure middleware
app.set('port', process.env.port || port); // set express to use this port
app.set('views', __dirname + '/views'); // set express to look in this folder to render our view
app.set('view engine', 'ejs'); // configure template engine
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()); // parse form data client
app.use(express.static(path.join(__dirname, 'public'))); // configure express to use public folder
app.use(fileUpload()); // configure fileupload

// routes for the app

app.get('/', getHomePage);
//app.get('/add', addPlayerPage);
//app.get('/edit/:id', editPlayerPage);
//app.get('/delete/:id', deletePlayer);
app.post('/add', addLink);
//app.post('/edit/:id', editPlayer);

app.get('/aURL/:id', function(req, res){
	var id = req.params.id;
	console.log("ID is "+id);

	var async = require('async');
	async.waterfall([async.apply(getMetaPoint, id)].concat(myArray),
		function(err, result){
			if(err){
				console.log("ERROR is "+err)
				res.send(err)
			}
			else {
				console.log("RESULT "+result);
				res.send(result);
			}
		}
	) 
})

app.get('/aURL', function(req, res){
	let type = req.query.Type;
	let locate = req.query.Location;
	let time = req.query.Time;
	let source = req.query.Source;

	var filter = "";
	var filterArray = [];
	var attributes = '';
	if(typeof type !== 'undefined' && typeof locate !== 'undefined' && typeof time !== 'undefined' && typeof source !== 'undefined'){
		res.send("No attributes specified")
		return;
	}
	if(typeof type !== 'undefined'){
		filterArray[0] = "Type="+type
		attributes = attributes + 'TYPE'+type+','
	}
	if(typeof locate !== 'undefined'){
		filterArray[1] = "Location="+locate
		attributes = attributes + 'LOCATION'+locate+','
	}
	if(typeof time !== 'undefined'){
		filterArray[2] = "Time="+time
		attributes = attributes + 'TIME'+time+','
	}
	if(typeof source !== 'undefined'){
		filterArray[3] = "Source="+source
		attributes = attributes + 'SOURCE'+source+','
	}

	for(var i = 0; i<4; i++){
		if(typeof filterArray[i] !== 'undefined')
			filter = filter + filterArray[i]+"&"
	}
	
	filter = filter.substring(0,filter.length - 1);
	console.log("Filter "+filter);
	attributes = attributes.substring(0, attributes.length - 1);
	console.log("Attributes "+attributes);

	var async = require('async');
	async.waterfall([async.apply(getMetaPointFilter, filter, attributes)].concat(Array2),
		function(err, result){
			if(err){
				console.log("ERROR is "+err)
				res.send(err)
			}
			else {
				console.log("RESULT "+result);
				res.send(result)
			}
		}
	)  

})

function getMetaPointFilter(filter, attr, cb){
  var request = require('request');
  console.log((new Date).getTime()+"Start Inside getMetaPoint filter "+filter)
  var fs = require('fs')
  // Set the headers
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json',
      'Authorization':    'Bearer '+token
  }
  timeout = 200000;
  // Configure the request
  var options = {
      url: "http://141.223.83.26:3000/posts?"+filter,
      method: 'GET',
      headers: headers,
  }
  console.log("Get metaPoint with http://141.223.83.26:3000/posts?"+filter)
  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200)
      {
          // Print out the response body
          var res = response.body;
          console.log(res)
          var metaArray = JSON.parse(response.body);
	  if(metaArray.length === 0){
		cb("cannot found the data")
	  }
	  for(var i = 0; i < metaArray.length; i++){
		 var jsonElement = metaArray[i];
		 var metacrypt = jsonElement['metacrypt'];
		 metacrypt = metacrypt.trim();
		 var id = jsonElement['id']
		 console.log("Metacrypt and id are "+metacrypt+","+id)
  /*	  	 fs.writeFile(id+".txt", metacrypt, function(err){
			if(err)
				console.log("Error is "+err);
			else 
				console.log("Successfully write to "+id)
		 });*/
		 let writeStream = fs.createWriteStream(id+'.txt')
		 writeStream.write(metacrypt, 'utf-8');

		 // the finish event is emitted when all data has been flushed from the stream
		 writeStream.on('finish', () => {  
    			console.log('wrote all data to file');
		 });

		 console.log("Time loop "+i)
		 if(i === metaArray.length - 1)
			cb(null, res, attr)
	  }
      }
  })

}

function getAndDecrypt(id){
	var async = require('async');
	async.waterfall([async.apply(getMetaPoint, id)].concat(myArray),
		function(err, result){
			if(err){
				console.log("ERROR is "+err)
			}
			else {
				console.log("RESULT "+result);
				return result;
			}
		}
	)  
} 

app.get('/authentication', function(req, res){
	var code = req.query.code;
	console.log("Code is "+code);
	if(typeof name !== "undefined"){
		res.send("Get authorization code success!");
	}

	console.log("Pre-Token is "+token);
	var request = require('request');

  	// Set the headers
 	 var headers = {
      		'Accept':           'application/json',
		'Authorization':    'Basic '+client_auth
  	}
  	timeout = 200000;
  	// Configure the request
 	 var options = {
      		url: 'http://141.223.83.26/dsu/oauth/token',
      		method: 'POST',
      		headers: headers,
      		form: {'grant_type' : 'authorization_code', 'code' : code, 'redirect_uri' : redirect_uri, 'client_id': client_id, 'client_secret' : client_secret}
  	}

  	// Start the request
  	request(options, function (error, response, body) {
    	if (!error && response.statusCode == 200) 
    	{
          	// Print out the response body
		var responseBody = JSON.parse(response.body);
		token = responseBody['access_token'];
		console.log("Token is "+token);
		res.send("Success");
    	}
      	else
        	console.log("Code error "+response.statusCode);
//		console.log(JSON.stringify(response.body));
  	})
}) 
app.post('/authentication',function(req, res){
	var body = req.body;
	console.log(JSON.stringify("Body is"+body));
})

function bindRequest(id, options){
}
function getMetaPoint(id, cb){
  var request = require('request');
  console.log("Inside getMetaPoint")

  // Set the headers
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json',
      'Authorization':    'Bearer '+token
  }
  timeout = 200000;
  // Configure the request
  var options = {
      url: "http://141.223.83.26:3000/posts?id="+id,
      method: 'GET',
      headers: headers,
  }

  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200)
      {
          // Print out the response body
          var res = response.body;
          console.log(res)
	  cb(null, res)
      }
  })

}

function decryptABE(ids){
}
var Array2 = [
function requestABE(metaContent, attr, callback){
  // Make a keygen request
  var metaArray = JSON.parse(metaContent);
  var ids = [];
  for(var i = 0; i < metaArray.length; i++){
	var element = metaArray[i];
	ids[i] = element['id'];
	console.log("IDs "+element['id'])
  }
  var request = require('request');
  console.log((new Date).getTime()+"Start keygen Inside getABE "+attr)
  var policies = attr;

request.post('http://141.223.121.191:5000/metaKeygen', {
  json: {
    policy: policies
  }
}, (error, res, body) => {
  if (error) {
    console.error(error)
    return
  }
  console.log((new Date).getTime()+"Finish ABE Key gen");
  console.log(`statusCode: ${res.statusCode}`)
  console.log(body)
  var fs = require('fs');
  fs.writeFileSync("key.txt", body, 'utf8');
  callback(null, metaContent, ids);

})
},
function abeDecrypt(metaContent, ids, callback) {
  var plainTextArr = [];
  console.log("Inside async abe decrypt "+(new Date).getTime())
  var j = 0;
  for (id of ids){
	  var plainText;
	//  var id = ids[j];
	  console.log("Jump to abe decrypt");
	  var exec = require('child_process').execSync;
	  console.log("Prepare to abe decrypt");
	  var stdout = exec("./decrypt_metadata.sh key.txt "+id+".txt").toString()
	    console.log(stdout)
	    var temp = stdout.split("\n");
	    var replaceAll = require('replaceall');
	    for (line of temp){
	      if(line.indexOf("Plaintext") > -1){
		plainText = line.substring(11, line.length);
		plainText = replaceAll("**", "\"", plainText);
		plainText = plainText.trim();
		console.log("Plain text is "+plainText)
		plainTextArr.push(plainText)
		console.log("Plaintext Array "+plainTextArr[j]);
//		callback(null, plainText, id);
	      }
	    }
	    
	  if(j === ids.length - 1){
		console.log("Prepare to jump to request duplicate")
  		console.log((new Date).getTime()+"PLAINTEXT "+plainTextArr)
  		callback(null, plainTextArr, ids);
	  }
	  j++
  }

},
function requestDuplicate(plainTextArr, ids,  callback){
  console.log("Inside request Duplicate");
  var newKey = "ARoAAQALAAMAcgAAAAYAgABDABAIAAABAAEBALcMxMIo5vCmUOIg7j3iZPjjJc633uhR+MuclV5x" +
                "0hT524s6ldyF4BmiFYv1TLM7pN6YrgJibgEw9xQE2yrZlw+UZcWweKPpTy+WeknTfXgdI2TRvwfk" +
                "QBXxwcXngCDoYN1VVhmojTrc2wawIR1KvMioiRfEfhqb/Rb3yyGxH3mECBkzW2P7WEPmrNyFWpPh" +
                "dg1wUiI/Q+7JWhH3gTbvOHae8zz5kEkOsG1RRle6PX9400sODQdPI42Qj2LEUMQxeuJwuK4N3e2U" +
                "mqO6ADZ/hQ3qzcrWsKEf56Bb1KZC+9WSiifIqPyGnWHcfrMzvBrmuTTlVM/sVJzMZlywK5ec2fU=";
  var myMap = new Map();
  var myMap2 = new Map();
  console.log((new Date).getTime()+"Request duplicate "+plainTextArr)
  var count = 0;
  for(let j = 0; j < plainTextArr.length; j++){
	  let id = ids[j]
	  var plainText = plainTextArr[j]
	  var metaJson = JSON.parse(plainText);
	  var keyName = metaJson['keyName'];
	  var SymEnc = metaJson['SymEnc'];
	  
	  var request = require('request');
	  console.log("Inside request Duplicate "+id)

	  // Set the headers
	  var headers = {
	      'User-Agent':       'Super Agent/0.0.1',
	      'Content-Type':     'application/json'
	  }
	  timeout = 200000;
	  // Configure the request
	  var options = {
	      url: "http://141.223.121.193:3000/directDuplicate",
	      method: 'POST',
	      headers: headers,
	      form: {"keyName" : keyName, 'newKey': newKey}
	  }

	  // Start the request
	  request(options, function (error, response, body) {
	      if (!error && response.statusCode == 200)
	      {
		  // Print out the response body
		  var res = response.body;
		  console.log((new Date).getTime()+"BLOB is "+res)
		  myMap2.set(id, res);
		  console.log("SIZE "+myMap2.size)
		  myMap.set(id,keyName);
		  console.log("My map "+myMap.size)
		  console.log("J and length "+j+""+plainTextArr.length)
		  count++;
	  	  if(count === plainTextArr.length){
			callback(null, myMap2, myMap);
	  	  }
	     }
	  })
  }
},
function importKeyBlob(myMap2, myMap, callback){
  console.log("Inside import key blob")
  var length = myMap2.size;
  console.log((new Date).getTime()+"before import Map length is "+length)
  var j = 0;
  for(var entry of myMap2.entries()){
          var id = entry[0];
	  var content = entry[1];
	  var body = JSON.parse(content);
	  var keyblob = body['keyblob'];
	  var keyName = body['keyName'];
	  console.log("Keyblob is "+JSON.stringify(keyblob));
	  console.log("ID is "+id);
	  // res.write("Hieu's return value");
	  var request = require('request');

	  // Set the headers
	  var headers = {
	      'User-Agent':       'Super Agent/0.0.1',
	      'Content-Type':     'application/json'
	  }
	  timeout = 200000;
	  // Configure the request
	  var options = {
	      url: 'http://141.223.121.193:3000/import',
	      method: 'POST',
	      headers: headers,
	      form: {'keyblob': keyblob, 'keyName' : keyName}
	  }

	  // Start the request
	  request(options, function (error, response, body) {
	      if (!error && response.statusCode == 200) 
	      {
		  // Print out the response body
		  var res = response.body;
		  console.log((new Date).getTime()+"Response of import blob "+res)
		//  callback(null, keyName, SymEnc, id
	 //     console.log(response.body)
	  	  if(j === length - 1){
		  	callback(null, myMap)
	  	  }
	  	  j++
	      }
	  })
  }
},
function getDataPointAsync(myMap, callback) {
  var request = require('request');
  var dataPointArr = [];
  var length = myMap.size;
  var j = 0;
  var promises = [];
  console.log("Get dataPoint async")
  for(var entry of myMap.entries()){
	  var id = entry[0];
	  var keyName = entry[1];
	  console.log("Inside getDataPoint "+id)

	  
	  var headers = {
	      'User-Agent':       'Super Agent/0.0.1',
	      'Content-Type':     'application/json',
	      'Authorization':    'Bearer '+token
	  }
	  console.log("Token "+token)
	  timeout = 200000;
	  
	  var options = {
	      url: 'http://141.223.83.26/dsu/dataPoints/'+id,
	      method: 'GET',
	      headers: headers,
	  }

	  
	  request(options, function (error, response, body) {
	      if (!error && response.statusCode == 200) 
	      {
		  // Print out the response body
		  var res = response.body;
		  console.log(res)
		  dataPointArr.push(res);
		  j = j + 1;
		  console.log("Length map is and j "+length+" "+j)
//		  callback(null, res, AESkey)
		  if(j === length){
			  console.log("Callback is call "+dataPointArr.length);
		  	  callback(null, dataPointArr)
	  	  }

	      }
	      else {
		console.log(error);
	      }
	      console.log(response.body)
	  
	})
  }

},

function tpmDecryptRequest(dataPointArr, callback){
  var request = require('request');
  var mapAESkey = new Map();
  var check = 0;
  var promises = []
  var count = 0;
  console.log("Before TPM decrypt "+(new Date).getTime())
  for(var j = 0; j < dataPointArr.length; j++){
	  console.log("Result dataPoint "+dataPointArr[j])
	  var dataPoint = JSON.parse(dataPointArr[j]);
	  var body = dataPoint['body'];
	  var keyName = body['keyName'];
	  var SymEnc = body['SymEnc']
	  var header = dataPoint['header']
	  let id = header['id'];
	  // Set the headers
	  var headers = {
	      'User-Agent':       'Super Agent/0.0.1',
	      'Content-Type':     'application/json',
	  }
	  timeout = 200000;
	  
	  // Configure the request
	 
	  var options = {
	      url: 'http://141.223.121.193:3000/tpmDec',
	      method: 'POST',
	      headers: headers,
	      json: {'keyName' : keyName, 'SymEnc' : SymEnc}
	  }
	//  console.log("Inside tpm decrypt "+JSON.stringify(keyInfo));
	  // Start the request
	  request(options, function (error, response, body) {
	      if (!error && response.statusCode == 200) 
	      {
		  console.log("Finish TPM decrypt "+(new Date).getTime())
		  var result = response.body;
		  console.log("Key content is "+JSON.stringify(result))
		  mapAESkey.set(id, JSON.stringify(result))
		  console.log("AES MAP KEY "+mapAESkey.size)
		  count++;
//	 	  promises.push(j)
		  if(count === dataPointArr.length)
			callback(null, dataPointArr, mapAESkey)
	      }
	})
   }	
//	Promise.all(promises)
//		.then(function(data){	callback(null, dataPointArr,mapAESkey)})
//		.catch(function(err){ console.log("Error is "+err)})

},

function AESdecrypt(dataPointArr, mapAESkey, callback) {
    var plainTextArr = [];
    var count = 0;
    for(var j = 0; j < dataPointArr.length; j++){
	    let dataPoint = JSON.parse(dataPointArr[j]);
	    let body = dataPoint['body'];
	    let keyName = dataPoint['keyName'];
	    let SymEnc = dataPoint['SymEnc']
	    var header = dataPoint['header']
	    var id = header['id'];
	    console.log("id before decrypt "+id)
	    let AESkey = mapAESkey.get(id);
   
	    console.log("AES key is "+AESkey)
	    let json = JSON.parse(AESkey);
	    let keyContent = json['KeyContent'];
	    let Keybuf = Buffer.from(keyContent, 'base64');
	    console.log("Decrypting "+id+" and Create keybuff from keycontent "+keyContent)
//	    console.log("Datapoints get "+res);
//	    var json = dataPoint;
//	    var body = json['body']
	    let crypt = body['crypt']
	    let cryp = require('crypto')
	    console.log((new Date).getTime()+": Before AES")
	    let iv = Buffer.alloc(0);
	    let decipher = cryp.createDecipheriv('aes-128-ecb', Keybuf, iv)
	    decipher.setAutoPadding(false);
	    let plainText = decipher.update(crypt,'base64', 'utf8')
	    console.log("PlainText datapoint is "+plainText);
	    delete dataPoint['body']
	    dataPoint['body'] = plainText;
	    let dataPointText = JSON.stringify(dataPoint);
	    let replaceall = require("replaceall")
	    dataPointText = dataPointText.replace(/\\/g, "")
	    console.log("DataPointText "+dataPointText)
	    plainTextArr.push(dataPointText);
	//    callback(null, plainText);
	    console.log("TIME J "+j+"dataPoint Array "+dataPointArr.length)
	    count++;
	    if(count === dataPointArr.length){
		console.log((new Date).getTime()+"Finish all tasks")
	    	callback(null,JSON.stringify(plainTextArr));	
	    }
    }

}
];

var myArray = [
function requestABE(metaContent, callback){
  console.log("Jump to request ABE");
  var replaceAll = require('replaceall');
//  metaContent = replaceAll(/\r?\n/g, "", metaContent);
  metaContent = replaceAll("[", "", metaContent);
  metaContent = replaceAll("]", "", metaContent);
//  metaContent = metaContent.replace(/\"/g, '');
  var newMeta = metaContent.replace(/\\n/g, '');
  var jsonMeta = JSON.parse(newMeta);
  console.log("Inside request ABE "+jsonMeta);
  var id = jsonMeta['id'];
  var metacrypt = jsonMeta['metacrypt'];
  console.log("id ane meta are "+id+","+metacrypt)
  delete jsonMeta['id'];
  delete jsonMeta['metacrypt'];
  console.log("JSON meta after "+JSON.stringify(jsonMeta));
  var fs = require('fs');
  fs.writeFileSync(id+".txt", metacrypt, 'utf8');
  var policies = "";
  for (var key in jsonMeta){
   if(policies === "")
     policies = key.toUpperCase()+""+jsonMeta[key];
  else
     policies = policies + "," + key.toUpperCase()+""+jsonMeta[key];
  }
  // Make a keygen request
  var request = require('request');
  console.log("Inside getABE "+policies)
  

request.post('http://141.223.121.191:5000/metaKeygen', {
  json: {
    policy: policies
  }
}, (error, res, body) => {
  if (error) {
    console.error(error)
    return
  }
  console.log(`statusCode: ${res.statusCode}`)
  console.log(body)
  var fs = require('fs');
  fs.writeFileSync("key.txt", body, 'utf8');
  callback(null, id+"key.txt", id);

})
  // Set the headers
/*
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json'
  }
  timeout = 200000;
  // Configure the request
  var options = {
      url: "http://141.223.121.191:5000/metaKeygen",
      method: 'POST',
      headers: headers,
      form: {"policy" : "abc"}
  }

  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200)
      {
          // Print out the response body
          var res = response.body;
          console.log(res)
	  var fs = require('fs');
          fs.writeFileSync(id+"key.txt", res);
	  callback(id+"key.txt", id);
      }
      console.log(response.body)
  }) */

},

function abeDecrypt(metaContent, id, callback) {
  var plainText;
  console.log("Jump to abe decrypt");
  var exec = require('child_process').exec;
  console.log("Prepare to abe decrypt");
  var decryptProcess = exec("./decrypt_metadata.sh key.txt "+id+".txt", function(err, stdout, stderr){
    console.log(stdout)
    var temp = stdout.split("\n");
    var replaceAll = require('replaceall');
    for(var i = 0; i < temp.length;i++){
      if(temp[i].indexOf("Plaintext") > -1){
        plainText = temp[i].substring(11, temp[i].length);
        plainText = replaceAll("**", "\"", plainText);
        plainText = plainText.trim();
        console.log("Plain text is "+plainText)
        callback(null, plainText, id);
      }
    }
    if(err){
      console.log("Error happened!")
      return;
    }
  })
},

function requestDuplicate(plainText, id,  callback){
  var newKey = "ARoAAQALAAMAcgAAAAYAgABDABAIAAABAAEBALcMxMIo5vCmUOIg7j3iZPjjJc633uhR+MuclV5x" +
                "0hT524s6ldyF4BmiFYv1TLM7pN6YrgJibgEw9xQE2yrZlw+UZcWweKPpTy+WeknTfXgdI2TRvwfk" +
                "QBXxwcXngCDoYN1VVhmojTrc2wawIR1KvMioiRfEfhqb/Rb3yyGxH3mECBkzW2P7WEPmrNyFWpPh" +
                "dg1wUiI/Q+7JWhH3gTbvOHae8zz5kEkOsG1RRle6PX9400sODQdPI42Qj2LEUMQxeuJwuK4N3e2U" +
                "mqO6ADZ/hQ3qzcrWsKEf56Bb1KZC+9WSiifIqPyGnWHcfrMzvBrmuTTlVM/sVJzMZlywK5ec2fU=";
  var metaJson = JSON.parse(plainText);
  var keyName = metaJson['keyName'];
  var SymEnc = metaJson['SymEnc'];
  
  var request = require('request');
  console.log("Inside request Duplicate "+id)

  // Set the headers
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json'
  }
  timeout = 200000;
  // Configure the request
  var options = {
      url: "http://141.223.121.193:3000/directDuplicate",
      method: 'POST',
      headers: headers,
      form: {"keyName" : keyName, 'newKey': newKey}
  }

  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200)
      {
          // Print out the response body
          var res = response.body;
          console.log(res)
	  callback(null,res, SymEnc, id); // should call to import
      }
//      console.log(response.body)
  })

},

function importKeyBlob(content, SymEnc, id, callback){
  var body = JSON.parse(content);
  var keyblob = body['keyblob'];
  var keyName = body['keyName'];
  console.log("Keyblob is "+JSON.stringify(keyblob));
  console.log("ID is "+id);
  // res.write("Hieu's return value");
  var request = require('request');

  // Set the headers
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json'
  }
  timeout = 200000;
  // Configure the request
  var options = {
      url: 'http://141.223.121.193:3000/import',
      method: 'POST',
      headers: headers,
      form: {'keyblob': keyblob, 'keyName' : keyName}
  }

  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200) 
      {
          // Print out the response body
          var res = response.body;
          console.log("Response is "+res)
	  callback(null, keyName, SymEnc, id)
      }
 //     console.log(response.body)
  })
},

function tpmDecryptRequest(keyName, SymEnc, id, callback){
  var request = require('request');

  // Set the headers
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json',
  }
  timeout = 200000;
  
  // Configure the request
 
  var options = {
      url: 'http://141.223.121.193:3000/tpmDec',
      method: 'POST',
      headers: headers,
      form: {'keyName' : keyName, 'SymEnc' : SymEnc}
  }
//  console.log("Inside tpm decrypt "+JSON.stringify(keyInfo));
  // Start the request
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200) 
      {
          var result = response.body;
          console.log("Key content is "+result)
          callback(null, id, result);
          return JSON.stringify(result)
      }
  })
},

function getDataPointAsync(id, AESkey, callback) {
  var request = require('request');
  console.log("Inside getDataPoint "+id)

  
  var headers = {
      'User-Agent':       'Super Agent/0.0.1',
      'Content-Type':     'application/json',
      'Authorization':    'Bearer '+token
  }
  timeout = 200000;
  
  var options = {
      url: 'http://141.223.83.26/dsu/dataPoints/'+id,
      method: 'GET',
      headers: headers,
  }

  
  request(options, function (error, response, body) {
      if (!error && response.statusCode == 200) 
      {
          // Print out the response body
          var res = response.body;
          console.log(res)
          callback(null, res, AESkey);
      }
      else {
	console.log(error);
      }
      console.log(response.body)
  })
},

function AESdecrypt(res, AESkey, callback) {
    console.log("AES key is "+AESkey)
    var json = JSON.parse(AESkey);
    var keyContent = json['KeyContent'];
    var Keybuf = Buffer.from(keyContent, 'base64');
    console.log("Datapoints get "+res);
    var json = JSON.parse(res)
    var body = json['body']
    var crypt = body['crypt']
    var cryp = require('crypto')
    console.log((new Date).getTime()+": Before AES")
    var iv = Buffer.alloc(0);
    var decipher = cryp.createDecipheriv('aes-128-ecb', Keybuf, iv)
    decipher.setAutoPadding(false);
    var plainText = decipher.update(crypt,'base64', 'utf8')
    console.log("PlainText datapoint is "+plainText);
    callback(null, plainText);
}
];


// set the app to listen on the port
app.listen(port, () => {
    console.log(`Server running on port: ${port}`);
});

